<?php
    class Model
    {

    }
?>